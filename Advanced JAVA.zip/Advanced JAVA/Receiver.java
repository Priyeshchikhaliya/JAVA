import java. net.*;
class Receiver
{
public static void main (String agrs[]){
try{

DatagramSocket ds=new DatagramSocket(7777);
byte[] buffer= new byte[1024];
DatagramPacket dp= new DatagramPacket(buffer, buffer.length);
ds.receive(dp);
String msg= new String (dp.getData() ,0, dp.getLength());
System.out.println ("Message received:: "+ msg);
}

catch(Exception e)
{
e.printStackTrace();
}
}
}