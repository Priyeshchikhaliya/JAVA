import java.rmi.*;

public class MyClient{
	public static void main(String args[]){
		try{
			Adder stub  = (Adder)Naming.lookup("rmi://localhost:5000/obj");
			System.out.println(stub.add(1,2));
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}