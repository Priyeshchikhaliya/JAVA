import java.net.*;
import java.util.*;
import java.io.*;

class Breceiver{
	public static void main(String args[])
	{	
		try{
			DatagramSocket ds = new DatagramSocket(1111);
			Scanner kb = new Scanner(System.in);
			InetAddress ip = InetAddress.getLocalHost();
			DatagramPacket dp;
			DatagramPacket dp1;
			//String msg = new String("");
			String smsg = new String("");
			

			while(smsg.equals("bye") != true)
			{
			//Receive data
			byte[] buffer = new byte[1024];
			dp1 = new DatagramPacket(buffer,buffer.length);
			ds.receive(dp1);
			String msg = new String(dp1.getData(),0,dp1.getLength());			
			System.out.println("Received message (Receiver side): " +msg);
			
			
			//Send data
			System.out.println("Enter the message (Receiver side): ");
			smsg = kb.nextLine();
			byte[] sbuffer = smsg.getBytes();
			dp = new DatagramPacket(smsg.getBytes(),smsg.length(),ip,7777);
			ds.send(dp);
			
			
	
			}
			ds.close();
		}	
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

			
			
			