import java.net.*;
import java.util.*;
import java.io.*;

class Bsender{
	public static void main(String args[])
	{
		try{
			DatagramSocket ds = new DatagramSocket(7777);
			InetAddress ip = InetAddress.getLocalHost();
			Scanner kb = new Scanner(System.in);
			DatagramPacket dp;
			DatagramPacket dp1;
			String msg = new String("");
			String rmsg = new String("");
			

			while(rmsg.equals("bye") != true)
			{
			//Send msg

			System.out.println("Enter the message (Sender side): ");
			msg = kb.nextLine();
			byte[] buffer = msg.getBytes();
			dp1 = new DatagramPacket(buffer,buffer.length,ip,1111);
			ds.send(dp1);
						
			//Receive msg

			byte[] rdata = new byte[1024];
			dp = new DatagramPacket(rdata,rdata.length);
			ds.receive(dp);
			rdata = rmsg.getBytes();
			rmsg = new String(dp.getData(),0,dp.getLength());
			System.out.println("Received message (Sender side): " +rmsg);
			
			
			
			
			}
			ds.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}