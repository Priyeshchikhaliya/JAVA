import java.net.*;
import java.io.*;
import java.util.*;

class ConcurrentEchoThread extends Thread{
		Socket news;
		
		ConcurrentEchoThread(Socket s){
			news=s;
		}
	
public void run(){
	try{
		InputStream ip = news.getInputStream();
		Scanner sc = new Scanner(ip);
		OutputStream out = news.getOutputStream();
		PrintWriter pw = new PrintWriter(out,true);
		
		Scanner kb = new Scanner(System.in);
		String msg;
		
		while(!(msg=sc.nextLine()).equals("bye")){
			System.out.println("Message of client: "+msg);
			char []A=new char[100];
			char []B=new char[100];
			int j=0;
			A=msg.toCharArray();
			for(int i=A.length-1;i>=0;i--)
			{
			B[j]=A[i];
			j++;
			}
			pw.println(B);
		}
		System.out.println("Message of client : bye");
		news.close();

	}
	catch(Exception e){
		e.printStackTrace();
	}
}
}
