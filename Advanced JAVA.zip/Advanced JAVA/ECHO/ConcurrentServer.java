import java.net.*;
import java.util.*;
import java.io.*;

class ConcurrentServer{
	public static void main(String args[])
	{	
		try{
			ServerSocket ss =new ServerSocket(4444);
			System.out.println("Server started, waiting for request");
			
			for(;;){
				Socket s = ss.accept();
				System.out.println("Connected");
				System.out.println("Creating Thread");
				ConcurrentEchoThread t = new ConcurrentEchoThread(s);
				t.start();
			}
		}	
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

			
			
			