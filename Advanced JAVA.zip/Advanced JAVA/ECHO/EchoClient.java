import java.net.*;
import java.util.*;
import java.io.*;

class EchoClient{
	public static void main(String args[])
	{
		try{
			System.out.println("Sending request");
			Socket s = new Socket("localhost",4444);
			System.out.println("Connected");
			InputStream ip = s.getInputStream();
			Scanner sc = new Scanner(ip);
			OutputStream out = s.getOutputStream();
			PrintWriter pw = new PrintWriter(out,true);
			Scanner kb = new Scanner(System.in);
			String msg,echomsg;
			
			while(true)
			{
			System.out.println("Enter message");
			msg = kb.nextLine();
			pw.println(msg);
			if(msg.equals("bye")){
				break;
			}
			echomsg=sc.nextLine();
			System.out.println("Message from server is "+echomsg);
			}
		
	}
	catch(Exception e)
		{
			e.printStackTrace();
		}
}
}