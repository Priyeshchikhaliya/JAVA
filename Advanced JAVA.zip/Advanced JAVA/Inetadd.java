import java.net.*;
import java.io.*;
import java.util.*;

public class Inetadd{
	public static void main(String args[])
	{	 
		try{
		
		 
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}