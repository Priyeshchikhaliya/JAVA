import java.io.*;
import java.net.*;
import java.util.*;
class server
{
            public static void main(String args[]) throws Exception
            {
                        ServerSocket ss=new ServerSocket(7777);
                        Socket s=ss.accept();
                        System.out.println("connected..........");
                        DataInputStream in=new DataInputStream(s.getInputStream());
                        DataOutputStream out=new DataOutputStream(s.getOutputStream());
                        int r,i=0;
                        int n=in.readInt();
                        int a[]=new int[n];
                        int count=0;
                        System.out.println("Receiving Data...");
                        for(i=0;i<n;i++)
                        {
                                    a[i]=in.readInt();
                        }
                        System.out.println("Data Received");
                        System.out.println("Sorting Data...");
                        Arrays.sort(a);
                        System.out.println("Data Sorted");
                        System.out.println("Sending Data...");
                        for(i=0;i<n;i++)
                        {
                                    out.writeInt(a[i]);
                        }
                        s.close();
                        ss.close();
            }
}