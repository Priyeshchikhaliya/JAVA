import java.io.*;
import java.net.*;
import java.util.*;
public class Palclient
{
public static void main(String args[]) throws Exception
{
Socket s=new Socket("localhost",80);
PrintStream ps=new PrintStream(s.getOutputStream());
ps.println("MOM");
InputStream is=s.getInputStream();
BufferedReader br=new BufferedReader(new InputStreamReader(is));
String str;
while((str=br.readLine())!=null)
{
System.out.println(str);
}
ps.close();
s.close();
}
}