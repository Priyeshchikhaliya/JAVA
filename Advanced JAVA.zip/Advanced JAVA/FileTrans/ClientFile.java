import java.io.*;
import java.net.*;


class ClientFile{
	public static void main(String[] agrs){
		try{
		  Socket s=new Socket("localhost",4444);
          if(s.isConnected()){
			  System.out.println("Connected");
		  }
          FileOutputStream fout= new FileOutputStream("Receiver.txt");
          DataInputStream din=new DataInputStream(s.getInputStream());
          int r;
          while((r=din.read())!=-1){
			  fout.write((char)r);
		  }
          s.close();
		}
	    catch(Exception e){
			e.printStackTrace();
		}
	}
}