import java.net.*;
import java.io.*;

class ServerFile{
	public static void main(String agrs[]){
		try{
		int a;
		ServerSocket ss=new ServerSocket(4444);
        Socket s=ss.accept();
        System.out.println("connected");
        FileInputStream fin=new FileInputStream("Sender.txt");
        DataOutputStream dout=new DataOutputStream(s.getOutputStream());
        while((a=fin.read())!=-1){
			 dout.write(a);
		}
        System.out.println("\nFiletranfered");
        s.close();
        ss.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}