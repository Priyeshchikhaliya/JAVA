import java.sql.*;
import java.util.*;
class psd
{
	public static void main(String args[])
	{
		try{
			String driverName = "com.mysql.jdbc.Driver";
			Class.forName(driverName);
			Scanner sc = new Scanner(System.in);
			String url = "jdbc:mysql://localhost:3306/DB";
			String uname = "root";
			String password = "";
			Connection con = DriverManager.getConnection(url,uname,password);
			if(!con.isClosed()){
				System.out.println("Connection established");
			}
			int choice;
			do{
				System.out.println("Choices");
				System.out.println("1.Create table \n2.Insert value \n3.Update value \n4.Delete value \n5.Delete table \n6.Delete database!!!!");
				System.out.println("Enter choice");
				choice=sc.nextInt();
				switch(choice){
				  case 1:
					String query1 = "CREATE TABLE Finaltab(rollno varchar(50),name varchar(50))";
					PreparedStatement stmt = con.prepareStatement(query1);
					stmt.executeUpdate();
					System.out.println("Table created");
					break;
				  
				  case 2:
					String query2="insert into Finaltab values (1, 'Priyesh') ";
					PreparedStatement ps = con.prepareStatement(query2);
					ps.executeUpdate();
					System.out.println("Value inserted");
					break;
				  case 3:
					String query3="UPDATE Finaltab SET name='Yash' WHERE rollno=1";
					PreparedStatement ps1 = con.prepareStatement(query3);
					ps1.executeUpdate();
					System.out.println("Value updated");
					break;
				  case 4:
					String query4="DELETE FROM Finaltab WHERE rollno=1";
					PreparedStatement ps2 = con.prepareStatement(query4);
					ps2.executeUpdate();
					System.out.println("Value deleted");
					
					break;
				  case 5:
					String query5="DROP TABLE Finaltab";
					PreparedStatement ps3 = con.prepareStatement(query5);
					ps3.executeUpdate();
					System.out.println("Table deleted");
					break;
				   case 6:
					String query6="DROP DATABASE DB";
					PreparedStatement ps4 = con.prepareStatement(query6);
					ps4.executeUpdate();
					System.out.println("Database deleted !!!");
					break;
			}
			}while(choice!=0);
			
			
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}catch(SQLException ex){
			ex.printStackTrace();
		}
	}
}