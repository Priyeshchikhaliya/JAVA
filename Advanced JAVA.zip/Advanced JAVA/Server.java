import java.net.*;
import java.io.*;
import java.util.*;

class Server{
	public static void main(String args[])
	{
			try{
				ServerSocket ss = new ServerSocket(1234);
				System.out.println("Server started, Waiting for request");
				Socket s = ss.accept();
				System.out.println("Connected");
				OutputStream out = s.getOutputStream();
				PrintWriter pw = new PrintWriter(out,true);
				InputStream ip = s.getInputStream();
				Scanner sc = new Scanner(ip);
				String msg1 = sc.nextLine();
				System.out.println("Message from client is :" +msg1);
				System.out.println("Sending message");
				
				pw.println("Welcome client");
				while(msg1 != "bye")
				{
				Scanner kb =new Scanner (System. in) ;
				String inMsg=kb.nextLine () ;

				pw.println(inMsg) ;
				System.out.println ("sent") ;
				String msg =sc.nextLine () ;
				System.out.println ("message from server is:"+msg) ;
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			
	}
}