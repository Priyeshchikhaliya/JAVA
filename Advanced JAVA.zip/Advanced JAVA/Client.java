import java.net.*;
import java.io.*;
import java.util.*;

class Client{
	public static void main(String args[])
	{
			try{
				System.out.println("Sending request");
				Socket s = new Socket("localhost",1234);
				System.out.println("Connected");		
				InputStream ip = s.getInputStream();
				Scanner sc = new Scanner(ip);
				OutputStream out = s.getOutputStream(); 
				PrintWriter pw=new PrintWriter (out, true) ;
				String msg1 = sc.nextLine();
				System.out.println("Message from client is :" +msg1);
				System.out.println("Sending message");
				while( msg1 != "bye")
				{
				Scanner kb =new Scanner (System. in) ;
				String inMsg=kb.nextLine () ;

				pw.println(inMsg) ;
				System.out.println ("sent") ;
				String msg=sc.nextLine () ;
				System.out.println ("message from server is:"+inMsg) ;
				}
				
			}
			catch(Exception e){
				e.printStackTrace();
			}
			
	}
}