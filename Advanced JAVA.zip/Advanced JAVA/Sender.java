import java. net.*;
class Sender{
public static void main (String agrs []){
try{

DatagramSocket ds=new DatagramSocket();
InetAddress ip =InetAddress.getByName("localhost");
String msg="hello welcome";
byte[] buffer=msg.getBytes();
DatagramPacket dp= new DatagramPacket (buffer, buffer.length, ip, 7777);
ds.send(dp);

ds.close();
}
catch(Exception e)
{
e.printStackTrace();
}
}
}