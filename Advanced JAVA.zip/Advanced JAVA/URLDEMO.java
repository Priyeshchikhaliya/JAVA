import java.net.*;
import java.io.*;
import java.util.*;

public class URLDEMO{
	public static void main(String args[])
	{	 
		try{
		URL Myurl = new URL("https://www.javatpoint.com/java-tutorial");
		 System.out.println("Protocol" +Myurl.getProtocol());
		 System.out.println("Host" +Myurl.getHost());
		 System.out.println("Port" +Myurl.getPort());
		 System.out.println("File" +Myurl.getFile());
		 
		 URLConnection cn = Myurl.openConnection();
		 InputStream ip = cn.getInputStream();
		 int i;
		 Scanner sc = new Scanner(ip);
		 
		 while(sc.hasNextLine())
		 {
			 System.out.println(sc.nextLine());
			 
		 }
		 while((i=ip.read())!=-1)
		 {
			 System.out.print((char)i);
		 }
		 
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}